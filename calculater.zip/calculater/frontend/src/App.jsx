import { useState } from 'react'
import Landing from './components/Landing.jsx'
import AssessmentForm from './components/AssessmentForm.jsx'
import Results from './components/Results.jsx'

export default function App() {
  const [view, setView] = useState('landing')
  const [result, setResult] = useState(null)

  return (
    <>
      {view === 'landing' && <Landing onStart={() => setView('form')} />}
      {view === 'form' && (
        <AssessmentForm
          onResult={(r) => {
            setResult(r)
            setView('results')
          }}
        />
      )}
      {view === 'results' && (
        <Results
          result={result}
          onReset={() => {
            setResult(null)
            setView('landing')
          }}
        />
      )}
    </>
  )
}
