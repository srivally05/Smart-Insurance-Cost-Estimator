export default function Results({ result, onReset }) {
  const {
    estimated_cost = 0,
    risk_category = 'MEDIUM',
    bmi,
    suggestions = [],
  } = result || {}

  const riskClass = `results-risk risk-${(risk_category || 'medium').toLowerCase()}`
  const showBmi = typeof bmi === 'number' && Number.isFinite(bmi)

  return (
    <div className="results">
      <div className="results-card">
        <h1 className="results-title">Your Insurance Estimate</h1>

        <div className="results-cost">
          <div className="cost-label">Estimated Insurance Cost</div>
          <div className="cost-value">
            ₹{Math.round(estimated_cost).toLocaleString('en-IN')}/year
          </div>
        </div>

        <div className={riskClass}>
          <span className="risk-label">Risk Category</span>
          <span className="risk-value">{risk_category}</span>
        </div>

        {showBmi && <div className="results-bmi">Your BMI: {bmi.toFixed(1)}</div>}

        {suggestions.length > 0 && (
          <div className="results-suggestions">
            <h3>Suggestions</h3>
            <ul>
              {suggestions.map((s, i) => (
                <li key={i}>{s}</li>
              ))}
            </ul>
          </div>
        )}

        <button className="btn btn-primary results-reset" onClick={onReset}>
          Start New Assessment
        </button>
      </div>
    </div>
  )
}
