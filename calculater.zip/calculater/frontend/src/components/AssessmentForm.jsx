import { useState } from 'react'
import { predict } from '../api.js'

const STEP_TITLES = [
  'Personal Information',
  'Lifestyle Habits',
  'Health Conditions',
  'Financial Information',
]

const initialForm = {
  age: '',
  gender: '',
  height: '',
  weight: '',
  smoker: 'no',
  alcohol: 'never',
  exercise: 'none',
  diet: 'veg',
  diabetes: 'no',
  heart_problems: 'no',
  chronic_disease: 'no',
  marital_status: 'single',
  dependents: '',
  income: '',
  savings: '',
}

export default function AssessmentForm({ onResult }) {
  const [step, setStep] = useState(0)
  const [loading, setLoading] = useState(false)
  const [error, setError] = useState('')
  const [form, setForm] = useState(initialForm)

  const update = (key) => (e) => {
    setForm((f) => ({ ...f, [key]: e.target.value }))
  }

  const validateStep = () => {
    if (step === 0) {
      const age = Number(form.age)
      if (!form.age || !Number.isFinite(age) || age < 18 || age > 100) {
        return 'Please enter a valid age (18-100)'
      }
      if (!form.gender) {
        return 'Please select a gender'
      }
      const height = Number(form.height)
      if (!form.height || !Number.isFinite(height) || height <= 0 || height > 250) {
        return 'Please enter a valid height (cm)'
      }
      const weight = Number(form.weight)
      if (!form.weight || !Number.isFinite(weight) || weight <= 0 || weight > 300) {
        return 'Please enter a valid weight (kg)'
      }
    }
    if (step === 3) {
      const dependents = Number(form.dependents)
      if (
        form.dependents === '' ||
        !Number.isInteger(dependents) ||
        dependents < 0 ||
        dependents > 20
      ) {
        return 'Please enter a valid number of dependents (0-20)'
      }
      const income = Number(form.income)
      const savings = Number(form.savings)
      if (
        form.income === '' ||
        form.savings === '' ||
        !Number.isFinite(income) ||
        !Number.isFinite(savings) ||
        income < 0 ||
        savings < 0
      ) {
        return 'Please enter valid income and savings'
      }
    }
    return ''
  }

  const handleNext = async () => {
    const err = validateStep()
    if (err) {
      setError(err)
      return
    }
    setError('')
    if (step < 3) {
      setStep((s) => s + 1)
      return
    }
    // last step -> submit
    const payload = {
      age: parseInt(form.age, 10),
      gender: form.gender,
      height: parseFloat(form.height),
      weight: parseFloat(form.weight),
      smoker: form.smoker,
      alcohol: form.alcohol,
      exercise: form.exercise,
      diet: form.diet,
      diabetes: form.diabetes,
      heart_problems: form.heart_problems,
      chronic_disease: form.chronic_disease,
      marital_status: form.marital_status,
      dependents: parseInt(form.dependents, 10),
      income: parseInt(form.income, 10),
      savings: parseInt(form.savings, 10),
    }
    setLoading(true)
    try {
      const result = await predict(payload)
      onResult(result)
    } catch (e) {
      setError(e.message || 'Something went wrong. Please try again.')
    } finally {
      setLoading(false)
    }
  }

  const handleBack = () => {
    setError('')
    setStep((s) => Math.max(0, s - 1))
  }

  const bmiHint = (() => {
    const h = parseFloat(form.height)
    const w = parseFloat(form.weight)
    if (Number.isFinite(h) && Number.isFinite(w) && h > 0 && w > 0) {
      const bmi = w / (h / 100) ** 2
      if (Number.isFinite(bmi)) {
        return `BMI: ${bmi.toFixed(1)}`
      }
    }
    return ''
  })()

  return (
    <div className="app-form">
      <div className="form-header">
        <h1>Health Insurance Assessment</h1>
        <div className="step-indicator">
          {[0, 1, 2, 3].map((i) => (
            <div key={i} className={`step-dot${i === step ? ' active' : ''}`}>
              {i + 1}
            </div>
          ))}
        </div>
      </div>

      <h2 className="step-title">{STEP_TITLES[step]}</h2>

      <div className="form-content">
        {step === 0 && (
          <>
            <div className="form-group">
              <label>Age</label>
              <input
                type="number"
                min="18"
                max="100"
                placeholder="24"
                value={form.age}
                onChange={update('age')}
              />
            </div>
            <div className="form-group">
              <label>Gender</label>
              <select value={form.gender} onChange={update('gender')}>
                <option value="">Select</option>
                <option value="male">Male</option>
                <option value="female">Female</option>
              </select>
            </div>
            <div className="form-group">
              <label>Height (cm)</label>
              <input
                type="number"
                min="100"
                max="250"
                placeholder="170"
                value={form.height}
                onChange={update('height')}
              />
            </div>
            <div className="form-group">
              <label>Weight (kg)</label>
              <input
                type="number"
                placeholder="70"
                value={form.weight}
                onChange={update('weight')}
              />
              {bmiHint && <div className="bmi-hint">{bmiHint}</div>}
            </div>
          </>
        )}

        {step === 1 && (
          <>
            <div className="form-group">
              <label>Do you smoke?</label>
              <select value={form.smoker} onChange={update('smoker')}>
                <option value="no">No</option>
                <option value="yes">Yes</option>
              </select>
            </div>
            <div className="form-group">
              <label>Do you drink alcohol?</label>
              <select value={form.alcohol} onChange={update('alcohol')}>
                <option value="never">Never</option>
                <option value="occasionally">Occasionally</option>
                <option value="often">Often</option>
              </select>
            </div>
            <div className="form-group">
              <label>How often do you exercise?</label>
              <select value={form.exercise} onChange={update('exercise')}>
                <option value="none">None</option>
                <option value="weekly">Weekly</option>
                <option value="daily">Daily</option>
              </select>
            </div>
            <div className="form-group">
              <label>What type of diet do you follow?</label>
              <select value={form.diet} onChange={update('diet')}>
                <option value="veg">Veg</option>
                <option value="non-veg">Non-veg</option>
                <option value="mixed">Mixed</option>
              </select>
            </div>
          </>
        )}

        {step === 2 && (
          <>
            <div className="form-group">
              <label>Do you have diabetes?</label>
              <select value={form.diabetes} onChange={update('diabetes')}>
                <option value="no">No</option>
                <option value="yes">Yes</option>
              </select>
            </div>
            <div className="form-group">
              <label>Do you have heart problems?</label>
              <select value={form.heart_problems} onChange={update('heart_problems')}>
                <option value="no">No</option>
                <option value="yes">Yes</option>
              </select>
            </div>
            <div className="form-group">
              <label>Do you have chronic disease?</label>
              <select value={form.chronic_disease} onChange={update('chronic_disease')}>
                <option value="no">No</option>
                <option value="yes">Yes</option>
              </select>
            </div>
          </>
        )}

        {step === 3 && (
          <>
            <div className="form-group">
              <label>Marital Status</label>
              <select value={form.marital_status} onChange={update('marital_status')}>
                <option value="single">Single</option>
                <option value="married">Married</option>
                <option value="divorced">Divorced</option>
                <option value="widowed">Widowed</option>
              </select>
            </div>
            <div className="form-group">
              <label>Number of Dependents</label>
              <input
                type="number"
                min="0"
                max="20"
                placeholder="2"
                value={form.dependents}
                onChange={update('dependents')}
              />
            </div>
            <div className="form-group">
              <label>Annual Income (₹)</label>
              <input
                type="number"
                min="0"
                placeholder="800000"
                value={form.income}
                onChange={update('income')}
              />
            </div>
            <div className="form-group">
              <label>Savings (₹)</label>
              <input
                type="number"
                min="0"
                placeholder="200000"
                value={form.savings}
                onChange={update('savings')}
              />
            </div>
          </>
        )}
      </div>

      {error && <div className="form-error">{error}</div>}

      <div className="form-actions">
        <button
          className="btn btn-secondary"
          onClick={handleBack}
          disabled={step === 0 || loading}
        >
          Back
        </button>
        <button className="btn btn-primary" onClick={handleNext} disabled={loading}>
          {step === 3 ? (loading ? 'Calculating...' : 'Get Estimate') : 'Next'}
        </button>
      </div>
    </div>
  )
}
