const API_URL = import.meta.env.VITE_API_URL || 'http://localhost:8000'

export async function predict(data) {
  const res = await fetch(`${API_URL}/api/predict`, {
    method: 'POST',
    headers: { 'Content-Type': 'application/json' },
    body: JSON.stringify(data),
  })
  if (!res.ok) {
    let detail = ''
    try {
      const body = await res.json()
      detail = body?.detail ? JSON.stringify(body.detail) : ''
    } catch (e) {
      // ignore parse errors
    }
    throw new Error(`Request failed (${res.status})${detail ? ': ' + detail : ''}`)
  }
  return res.json()
}
